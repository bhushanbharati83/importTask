<!DOCTYPE html>
<html>

<head>
    <title>CSV Import</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <h2>Import Products CSV</h2>

        <?php if(session('summary')): ?>
            <div class="alert alert-success">
                <strong>Import Summary:</strong><br>
                Total: <?php echo e(session('summary.total')); ?><br>
                Created: <?php echo e(session('summary.created')); ?><br>
                Updated: <?php echo e(session('summary.updated')); ?><br>
                Invalid: <?php echo e(session('summary.invalid')); ?><br>
                Duplicates: <?php echo e(session('summary.duplicates')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('products.upload')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="csv_file" class="form-label">Select CSV file</label>
                <input type="file" name="csv_file" id="csv_file" class="form-control" required>
                <?php $__errorArgs = ['csv_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Import</button>
        </form>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ImportSKU\resources\views/products/import.blade.php ENDPATH**/ ?>